import axios from "axios";

const getBannerImages = async () => {
  return axios.get(`home/GetBannerImgList`).then((response) => {
    return response;
  });
};

const GetAccessHeadComponent = async () => {
  return axios.post(`Access/GetAccessHeadComponent`).then((response) => {
    return response;
  });
};

const GetUserByServiceNo = async () => {
  
  // let formData = new FormData();
  // formData.append("P_YEAR", "2018");
  // // formData.P_YEAR = "2018";

  // let config = {
  //   method: "post",
  //   url: "Medical/GetMedicalIndoorUsageDetails",
  //   data : formData,
  //   headers: { 
  //     'content-type': 'application/json'
  //   }
  // };
   
  // // formData.append("P_MONTH", month);


  // return axios.request(config).then((response) => {
  //   return response;
  // });

  return axios.post(`home/GetUserByServiceNo`).then((response) => {
    return response;
  });
};

export default {
  getBannerImages,
  GetAccessHeadComponent,
  GetUserByServiceNo,
};
